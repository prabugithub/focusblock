package com.prabu.focusblock

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private var startMin = 0
    private var endMin = 0
    private var selectedApps = mutableSetOf<String>()
    private val dayBoxes = mutableListOf<CheckBox>()
    private val editable = mutableListOf<View>()

    private lateinit var status: TextView
    private lateinit var enabledSwitch: Switch
    private lateinit var startBtn: Button
    private lateinit var endBtn: Button
    private lateinit var sitesEdit: EditText
    private lateinit var appsBtn: Button
    private lateinit var saveBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startMin = Prefs.startMin(this)
        endMin = Prefs.endMin(this)
        selectedApps = Prefs.apps(this).toMutableSet()
        setContentView(ScrollView(this).apply { addView(buildUi()) })
        refreshLabels()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(40))
        }
        fun label(t: String) = root.addView(TextView(this).apply {
            text = t
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(20), 0, dp(6))
        })

        status = TextView(this).apply { textSize = 15f }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        enabledSwitch = Switch(this).apply {
            text = "Blocking enabled"
            textSize = 16f
            isChecked = Prefs.enabled(this@MainActivity)
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(enabledSwitch)

        label("Block time")
        startBtn = Button(this).apply { setOnClickListener { pickTime(true) } }
        endBtn = Button(this).apply { setOnClickListener { pickTime(false) } }
        val timeRow = LinearLayout(this)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        timeRow.addView(startBtn, lp)
        timeRow.addView(endBtn, LinearLayout.LayoutParams(lp))
        root.addView(timeRow)

        label("Days")
        val savedDays = Prefs.days(this)
        val dayRow = LinearLayout(this)
        arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat").forEachIndexed { i, n ->
            val cb = CheckBox(this).apply { text = n; isChecked = (i + 1) in savedDays }
            dayBoxes.add(cb)
            dayRow.addView(cb)
        }
        root.addView(HorizontalScrollView(this).apply { addView(dayRow) })

        label("Blocked websites (one per line)")
        sitesEdit = EditText(this).apply {
            setText(Prefs.sites(this@MainActivity).joinToString("\n"))
            hint = "youtube.com\ninstagram.com"
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        root.addView(sitesEdit)

        label("Blocked apps")
        appsBtn = Button(this).apply { setOnClickListener { pickApps() } }
        root.addView(appsBtn)

        saveBtn = Button(this).apply {
            text = "Save"
            setOnClickListener { save() }
        }
        root.addView(saveBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24) })

        root.addView(TextView(this).apply {
            text = "Settings are locked while a block window is active, so you can't cheat mid-session."
            setPadding(0, dp(16), 0, 0)
        })

        editable.addAll(listOf(enabledSwitch, startBtn, endBtn, sitesEdit, appsBtn, saveBtn))
        editable.addAll(dayBoxes)
        return root
    }

    private fun refreshLabels() {
        startBtn.text = "From ${Prefs.fmt(startMin)}"
        endBtn.text = "To ${Prefs.fmt(endMin)}"
        appsBtn.text = "Choose apps (${selectedApps.size} selected)"
    }

    private fun refreshStatus() {
        val serviceOn = isServiceOn()
        val active = Prefs.isActiveNow(this)
        status.text = buildString {
            append(
                if (serviceOn) "✅ Blocker service is ON\n"
                else "⚠️ Blocker service is OFF. Tap the button below and turn on FocusBlock.\n"
            )
            append(
                if (active) "🔒 Block time active until ${Prefs.fmt(Prefs.endMin(this@MainActivity))}"
                else "🔓 Not in block time right now"
            )
        }
        editable.forEach { it.isEnabled = !active }
    }

    private fun pickTime(isStart: Boolean) {
        val cur = if (isStart) startMin else endMin
        TimePickerDialog(this, { _, h, m ->
            if (isStart) startMin = h * 60 + m else endMin = h * 60 + m
            refreshLabels()
        }, cur / 60, cur % 60, false).show()
    }

    private fun pickApps() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first != packageName }
            .sortedBy { it.second.lowercase() }

        val labels = apps.map { it.second }.toTypedArray()
        val checked = apps.map { it.first in selectedApps }.toBooleanArray()

        AlertDialog.Builder(this)
            .setTitle("Block these apps")
            .setMultiChoiceItems(labels, checked) { _, i, isChecked -> checked[i] = isChecked }
            .setPositiveButton("OK") { _, _ ->
                selectedApps = apps.filterIndexed { i, _ -> checked[i] }.map { it.first }.toMutableSet()
                refreshLabels()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun save() {
        val days = dayBoxes.mapIndexedNotNull { i, cb -> if (cb.isChecked) i + 1 else null }.toSet()
        val sites = sitesEdit.text.toString().lines()
            .map { Prefs.normalize(it) }
            .filter { it.isNotEmpty() }
            .distinct()
        Prefs.save(this, enabledSwitch.isChecked, startMin, endMin, days, selectedApps, sites)
        sitesEdit.setText(sites.joinToString("\n"))
        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        refreshStatus()
    }

    private fun isServiceOn(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val full = "$packageName/${BlockerService::class.java.name}"
        val short = "$packageName/.BlockerService"
        return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }
}
