package com.prabu.focusblock

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class BlockerService : AccessibilityService() {

    private var lastBlock = 0L
    private var lastUrlCheck = 0L

    /** Address-bar view IDs for common browsers. */
    private val browsers = mapOf(
        "com.android.chrome" to listOf("com.android.chrome:id/url_bar"),
        "com.chrome.beta" to listOf("com.chrome.beta:id/url_bar"),
        "com.brave.browser" to listOf("com.brave.browser:id/url_bar"),
        "com.microsoft.emmx" to listOf("com.microsoft.emmx:id/url_bar"),
        "com.kiwibrowser.browser" to listOf("com.kiwibrowser.browser:id/url_bar"),
        "com.vivaldi.browser" to listOf("com.vivaldi.browser:id/url_bar"),
        "org.mozilla.firefox" to listOf(
            "org.mozilla.firefox:id/mozac_browser_toolbar_url_view",
            "org.mozilla.firefox:id/url_bar_title"
        ),
        "com.sec.android.app.sbrowser" to listOf(
            "com.sec.android.app.sbrowser:id/location_bar_edit_text",
            "com.sec.android.app.sbrowser:id/custom_tab_toolbar_url_bar_text"
        ),
        "com.opera.browser" to listOf("com.opera.browser:id/url_field"),
        "com.opera.mini.native" to listOf("com.opera.mini.native:id/url_field"),
        "com.duckduckgo.mobile.android" to listOf("com.duckduckgo.mobile.android:id/omnibarTextInput")
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (!Prefs.isActiveNow(this)) return

        // 1) Blocked apps
        if (pkg in Prefs.apps(this)) {
            block("This app is blocked right now")
            return
        }

        // 2) Blocked websites in browsers
        val ids = browsers[pkg] ?: return
        val sites = Prefs.sites(this)
        if (sites.isEmpty()) return

        val now = System.currentTimeMillis()
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && now - lastUrlCheck < 400) return
        lastUrlCheck = now

        val root = rootInActiveWindow ?: return
        for (id in ids) {
            val nodes = try { root.findAccessibilityNodeInfosByViewId(id) } catch (_: Exception) { null } ?: continue
            for (node in nodes) {
                val text = node.text?.toString() ?: continue
                if (Prefs.hostMatches(text, sites)) {
                    block("${Prefs.normalize(text)} is blocked right now")
                    return
                }
            }
        }
    }

    private fun block(msg: String) {
        val now = System.currentTimeMillis()
        if (now - lastBlock < 1500) return
        lastBlock = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, "🔒 $msg", Toast.LENGTH_SHORT).show()
    }

    override fun onInterrupt() {}
}
