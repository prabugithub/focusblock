package com.prabu.focusblock

import android.content.Context
import java.util.Calendar

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("focusblock", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun startMin(c: Context) = sp(c).getInt("start", 9 * 60)
    fun endMin(c: Context) = sp(c).getInt("end", 18 * 60)

    /** Days use Calendar.DAY_OF_WEEK: 1 = Sunday ... 7 = Saturday. Default Mon–Fri. */
    fun days(c: Context): Set<Int> =
        sp(c).getStringSet("days", null)?.mapNotNull { it.toIntOrNull() }?.toSet()
            ?: setOf(2, 3, 4, 5, 6)

    fun apps(c: Context): Set<String> = sp(c).getStringSet("apps", null)?.toSet() ?: emptySet()

    fun sites(c: Context): List<String> =
        (sp(c).getString("sites", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun save(
        c: Context, enabled: Boolean, start: Int, end: Int,
        days: Set<Int>, apps: Set<String>, sites: List<String>
    ) {
        sp(c).edit()
            .putBoolean("enabled", enabled)
            .putInt("start", start)
            .putInt("end", end)
            .putStringSet("days", days.map { it.toString() }.toHashSet())
            .putStringSet("apps", HashSet(apps))
            .putString("sites", sites.joinToString("\n"))
            .apply()
    }

    /** "https://www.YouTube.com/watch?v=1" -> "youtube.com" */
    fun normalize(s: String): String =
        s.trim().lowercase()
            .removePrefix("https://").removePrefix("http://").removePrefix("www.")
            .substringBefore("/").substringBefore("?").substringBefore(":")

    fun hostMatches(urlText: String, sites: List<String>): Boolean {
        val host = normalize(urlText)
        if (host.isEmpty() || host.contains(' ')) return false
        return sites.any { host == it || host.endsWith(".$it") }
    }

    fun isActiveNow(c: Context): Boolean {
        if (!enabled(c)) return false
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val today = cal.get(Calendar.DAY_OF_WEEK)
        val yesterday = if (today == 1) 7 else today - 1
        val s = startMin(c)
        val e = endMin(c)
        val d = days(c)
        return when {
            s == e -> today in d                                   // whole day
            s < e -> today in d && now >= s && now < e             // e.g. 9 AM – 6 PM
            else -> (today in d && now >= s) || (yesterday in d && now < e) // overnight, e.g. 10 PM – 6 AM
        }
    }

    fun fmt(m: Int): String {
        val h = m / 60
        val mm = m % 60
        val ampm = if (h < 12) "AM" else "PM"
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "%d:%02d %s".format(h12, mm, ampm)
    }
}
